این پوشه یک پروژه Android آماده برای بسته‌بندی رابط JARVIS MAX است.
نکته: ZIP اصلی یک برنامه Node/Express است و خودش APK نیست؛ برای چت آنلاین، سرور Node باید جداگانه روی یک HTTPS URL اجرا شود.
داخل برنامه از دکمه «اتصال» آدرس سرور را وارد کن.
برای ساخت APK بدون نصب Android Studio، پروژه را در GitHub بگذار و از Actions > Build APK اجرا کن؛ فایل APK در Artifacts قرار می‌گیرد.
